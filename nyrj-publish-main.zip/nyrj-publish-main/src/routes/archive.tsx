import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { SiteLayout } from "@/components/SiteLayout";
import { getLibrary, removeEntry, updateEntry, type LibraryEntry } from "@/lib/library";
import { getSession, isStaff, onAuthChange, type Session } from "@/lib/auth";

export const Route = createFileRoute("/archive")({
  head: () => ({
    meta: [
      { title: "Library — Published Student Research | NYRJ" },
      { name: "description", content: "Browse every peer-reviewed manuscript published in the National Youth Research Journal — original student research across every academic discipline." },
      { name: "keywords", content: "NYRJ library, published student research, youth research archive, peer reviewed student papers, open access student manuscripts" },
      { property: "og:title", content: "Library — Published Student Research | NYRJ" },
      { property: "og:description", content: "Every peer-reviewed manuscript published in the National Youth Research Journal." },
      { property: "og:url", content: "https://nyrj.org/archive" },
    ],
    links: [{ rel: "canonical", href: "https://nyrj.org/archive" }],
  }),
  component: Library,
});

const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

const JOURNAL_TITLE = "National Youth Research Journal (NYRJ)";
const SITE_URL = "https://nyrj.org";

function splitAuthors(authors: string): string[] {
  const trimmed = authors.trim();
  // Prefer strong separators first so "Last, First; Last, First" survives intact.
  let parts: string[];
  if (trimmed.includes(";")) {
    parts = trimmed.split(/\s*;\s*/);
  } else if (/\s+(?:and|&)\s+/i.test(trimmed)) {
    parts = trimmed.split(/\s+(?:and|&)\s+/i);
  } else {
    parts = trimmed.split(/\s*,\s*/);
  }
  return parts.map((s) => s.trim()).filter(Boolean);
}

/** Convert a single name to APA "Last, F. M." form. Accepts "First M Last" or "Last, First M". */
function toApaName(full: string): string {
  const s = full.trim();
  if (!s) return "";
  if (s.includes(",")) {
    const [last, rest = ""] = s.split(/\s*,\s*/, 2);
    const givens = rest.trim().split(/\s+/).filter(Boolean);
    if (!givens.length) return last;
    const initials = givens.map((p) => `${p[0]?.toUpperCase()}.`).join(" ");
    return `${last}, ${initials}`;
  }
  const parts = s.split(/\s+/);
  if (parts.length === 1) return `${parts[0]}.`;
  const last = parts[parts.length - 1];
  const initials = parts.slice(0, -1).map((p) => `${p[0]?.toUpperCase()}.`).join(" ");
  return `${last}, ${initials}`;
}

/** Join author list per APA: "A", "A, & B", "A, B, & C". */
function joinApaAuthors(names: string[]): string {
  if (names.length === 0) return "";
  if (names.length === 1) return names[0];
  if (names.length === 2) return `${names[0]}, & ${names[1]}`;
  return `${names.slice(0, -1).join(", ")}, & ${names[names.length - 1]}`;
}

/** APA-style citation for a Library entry. */
function formatCitation(e: LibraryEntry): string {
  const year = new Date(e.addedAt).getFullYear();
  const apaAuthors = joinApaAuthors(splitAuthors(e.authors).map(toApaName));
  const issuePart = e.issue ? `, ${e.issue}` : "";
  const tail = e.doi ? ` https://doi.org/${e.doi}` : ` ${SITE_URL}/article/${e.slug}`;
  return `${apaAuthors} (${year}). ${e.title}. ${JOURNAL_TITLE}${issuePart}.${tail}`;
}

function CopyCitationButton({ entry }: { entry: LibraryEntry }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      onClick={async (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        try {
          await navigator.clipboard.writeText(formatCitation(entry));
          setCopied(true);
          setTimeout(() => setCopied(false), 1500);
        } catch {
          /* ignore */
        }
      }}
      className="shrink-0 px-3 py-1.5 border border-border text-[10px] uppercase tracking-[0.2em] hover:bg-primary hover:text-primary-foreground transition"
      title="Copy APA citation"
    >
      {copied ? "Copied ✓" : "Copy citation"}
    </button>
  );
}

function Library() {
  const [entries, setEntries] = useState<LibraryEntry[]>([]);
  const [ready, setReady] = useState(false);
  const [session, setSession] = useState<Session | null>(null);

  const [q, setQ] = useState("");
  const [year, setYear] = useState("all");
  const [month, setMonth] = useState("all");
  const [topic, setTopic] = useState("all");
  const [grade, setGrade] = useState("all");

  useEffect(() => {
    getLibrary().then((list) => {
      setEntries(list);
      setReady(true);
    });
    setSession(getSession());
    return onAuthChange(setSession);
  }, []);

  const staff = isStaff(session);

  async function handleRemove(id: string, title: string) {
    if (!window.confirm(`Remove "${title}" from the Library? This cannot be undone.`)) return;
    await removeEntry(id);
    setEntries(await getLibrary());
  }

  const years = useMemo(() => {
    const s = new Set<number>();
    entries.forEach((e) => s.add(new Date(e.addedAt).getFullYear()));
    return Array.from(s).sort((a, b) => b - a);
  }, [entries]);

  const topics = useMemo(() => {
    const s = new Set<string>();
    entries.forEach((e) => { if (e.topic) s.add(e.topic); });
    return Array.from(s).sort();
  }, [entries]);

  const grades = useMemo(() => {
    const s = new Set<string>();
    entries.forEach((e) => { if (e.grade) s.add(e.grade); });
    return Array.from(s).sort();
  }, [entries]);

  const filtered = useMemo(() => {
    const qq = q.trim().toLowerCase();
    return entries.filter((e) => {
      if (qq) {
        const hay = `${e.title} ${e.authors} ${e.issue ?? ""} ${e.topic ?? ""} ${e.grade ?? ""}`.toLowerCase();
        if (!hay.includes(qq)) return false;
      }
      const d = new Date(e.addedAt);
      if (year !== "all" && d.getFullYear() !== Number(year)) return false;
      if (month !== "all" && d.getMonth() !== Number(month)) return false;
      if (topic !== "all" && (e.topic ?? "") !== topic) return false;
      if (grade !== "all" && (e.grade ?? "") !== grade) return false;
      return true;
    });
  }, [entries, q, year, month, topic, grade]);

  const anyFilter = q !== "" || year !== "all" || month !== "all" || topic !== "all" || grade !== "all";

  return (
    <SiteLayout>
      <section className="mx-auto max-w-4xl px-6 py-16">
        <p className="text-[10px] uppercase tracking-[0.35em] text-accent">Published Manuscripts</p>
        <h1 className="font-serif text-4xl sm:text-5xl text-primary mt-3">Library</h1>
        <p className="mt-3 text-muted-foreground max-w-2xl">
          The complete public record of every manuscript published in the National Youth Research
          Journal can be accessed through our webite. Tap any title to open the full manuscript.
        </p>

        {/* Search + Filters */}
        <div className="mt-8 border border-border bg-card p-4 space-y-3">
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search by title, author, topic…"
            className="w-full border border-border bg-background px-3 py-2 text-sm"
          />
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <FilterSelect
              label="Year"
              value={year}
              onChange={setYear}
              options={[{ value: "all", label: "All years" }, ...years.map((y) => ({ value: String(y), label: String(y) }))]}
            />
            <FilterSelect
              label="Month"
              value={month}
              onChange={setMonth}
              options={[{ value: "all", label: "All months" }, ...MONTHS.map((m, i) => ({ value: String(i), label: m }))]}
            />
            <FilterSelect
              label="Topic"
              value={topic}
              onChange={setTopic}
              options={[{ value: "all", label: "All topics" }, ...topics.map((t) => ({ value: t, label: t }))]}
            />
            <FilterSelect
              label="Grade"
              value={grade}
              onChange={setGrade}
              options={[{ value: "all", label: "All grades" }, ...grades.map((g) => ({ value: g, label: g }))]}
            />
          </div>
          {anyFilter && (
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>
                Showing {filtered.length} of {entries.length}
              </span>
              <button
                type="button"
                onClick={() => { setQ(""); setYear("all"); setMonth("all"); setTopic("all"); setGrade("all"); }}
                className="text-accent hover:text-primary underline underline-offset-4"
              >
                Clear filters
              </button>
            </div>
          )}
        </div>

        {ready && entries.length === 0 ? (
          <div className="mt-12 border-2 border-dashed border-border bg-card px-6 py-12 text-center">
            <p className="font-serif text-2xl text-primary">No manuscripts published yet.</p>
            <p className="mt-3 text-muted-foreground max-w-xl mx-auto">
              New articles are added on a rolling basis as soon as they clear review.
            </p>
          </div>
        ) : ready && filtered.length === 0 ? (
          <div className="mt-12 border-2 border-dashed border-border bg-card px-6 py-12 text-center">
            <p className="font-serif text-2xl text-primary">No matches.</p>
            <p className="mt-3 text-muted-foreground">Try a different search or clear filters.</p>
          </div>
        ) : (
          <ul className="mt-10 divide-y divide-border border-t-2 border-primary">
            {filtered.map((e) => (
              <li key={e.id} className="py-5">
                <div className="flex items-start justify-between gap-4">
                  <Link
                    to="/article/$slug"
                    params={{ slug: e.slug }}
                    className="group block flex-1"
                  >
                    <h3 className="font-serif text-2xl text-primary group-hover:text-accent transition">
                      {e.title}
                      {e.featured && (
                        <span className="ml-2 align-middle text-[9px] uppercase tracking-[0.2em] bg-accent text-accent-foreground px-2 py-0.5">
                          Featured
                        </span>
                      )}
                    </h3>
                    <p className="mt-1 text-sm text-foreground/80">{e.authors}</p>
                    <p className="mt-1 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                      {e.issue ? `${e.issue} · ` : ""}
                      {new Date(e.publicationDate ?? e.addedAt).toLocaleDateString(undefined, {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                      {e.doi ? ` · DOI: ${e.doi}` : ""}
                      {" · "}Read article →
                    </p>
                    {(e.topic || e.grade) && (
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {e.topic && (
                          <span className="text-[10px] uppercase tracking-[0.2em] border border-border px-2 py-0.5 text-foreground/80">
                            {e.topic}
                          </span>
                        )}
                        {e.grade && (
                          <span className="text-[10px] uppercase tracking-[0.2em] border border-border px-2 py-0.5 text-foreground/80">
                            Grade {e.grade}
                          </span>
                        )}
                      </div>
                    )}
                  </Link>

                  <div className="flex flex-col items-end gap-2 shrink-0">
                    {e.awardWinner && (
                      <span
                        className="inline-flex items-center gap-1 bg-blue-600 text-white text-[10px] uppercase tracking-[0.2em] font-semibold px-2.5 py-1 rounded-sm shadow-sm"
                        title={e.awardLabel ?? "Award Winner"}
                      >
                        🏆 {e.awardLabel ?? "Award Winner"}
                      </span>
                    )}
                    <CopyCitationButton entry={e} />
                    {staff && (
                      <button
                        type="button"
                        onClick={() => handleRemove(e.id, e.title)}
                        className="px-3 py-1.5 border border-destructive text-destructive text-[10px] uppercase tracking-[0.2em] hover:bg-destructive hover:text-destructive-foreground transition"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                </div>
                {staff && (
                  <StaffEntryEditor
                    entry={e}
                    onSaved={async () => setEntries(await getLibrary())}
                  />
                )}
              </li>
            ))}
          </ul>
        )}

        <article className="mt-12 border-t-2 border-primary pt-6">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <h3 className="font-serif text-2xl text-primary">Open for Submissions</h3>
            <p className="text-xs uppercase tracking-[0.2em] text-accent">Rolling Publication</p>
          </div>
          <p className="mt-3 text-sm text-foreground/90">
            Submit your manuscript today. Accepted articles are published as soon as they clear review.
          </p>
          <Link
            to="/submit"
            className="inline-block mt-4 px-5 py-2.5 bg-primary text-primary-foreground text-xs uppercase tracking-[0.2em] hover:bg-accent transition"
          >
            Apply for Publication
          </Link>
        </article>

        {staff && (
          <p className="mt-10 text-xs text-muted-foreground">
            Staff mode: remove buttons are visible next to each manuscript.
          </p>
        )}
      </section>
    </SiteLayout>
  );
}

function FilterSelect({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <div>
      <label className="block text-[10px] uppercase tracking-[0.2em] text-accent mb-1">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full border border-border bg-background px-2 py-1.5 text-sm"
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>{o.label}</option>
        ))}
      </select>
    </div>
  );
}

function StaffEntryEditor({
  entry,
  onSaved,
}: {
  entry: LibraryEntry;
  onSaved: () => Promise<void> | void;
}) {
  const [open, setOpen] = useState(false);
  const [doi, setDoi] = useState(entry.doi ?? "");
  const [featured, setFeatured] = useState(entry.featured);
  const [awardWinner, setAwardWinner] = useState(entry.awardWinner);
  const [awardLabel, setAwardLabel] = useState(entry.awardLabel ?? "");
  const [orcids, setOrcids] = useState(entry.orcids?.join(", ") ?? "");
  const [issue, setIssue] = useState(entry.issue ?? "");
  const [publicationDate, setPublicationDate] = useState(entry.publicationDate ?? "");
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  async function handleSave() {
    setSaving(true);
    setMsg("");
    try {
      const orcidList = orcids
        .split(",")
        .map((s: string) => s.trim())
        .filter(Boolean);
      await updateEntry(entry.id, {
        doi: doi.trim() || null,
        featured,
        awardWinner,
        awardLabel: awardWinner ? (awardLabel.trim() || null) : null,
        orcids: orcidList.length ? orcidList : null,
        issue: issue.trim() || null,
        publicationDate: publicationDate.trim() || null,
      });
      setMsg("Saved.");
      await onSaved();
      setTimeout(() => setMsg(""), 1500);
    } catch (err) {
      setMsg(err instanceof Error ? err.message : "Save failed.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="mt-2">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="text-[10px] uppercase tracking-[0.2em] text-accent hover:text-primary underline underline-offset-4"
      >
        {open ? "Close editor" : "Edit issue / date / DOI / featured / award / ORCIDs"}

      </button>
      {open && (
        <div className="mt-3 border border-border bg-card p-4 space-y-3 text-sm">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] uppercase tracking-[0.2em] text-accent mb-1">Issue</label>
              <input
                value={issue}
                onChange={(e) => setIssue(e.target.value)}
                placeholder="Vol. 2, Issue 1"
                className="w-full border border-border bg-background px-2 py-1.5"
              />
            </div>
            <div>
              <label className="block text-[10px] uppercase tracking-[0.2em] text-accent mb-1">Publication date</label>
              <input
                type="date"
                value={publicationDate}
                onChange={(e) => setPublicationDate(e.target.value)}
                className="w-full border border-border bg-background px-2 py-1.5"
              />
            </div>
          </div>
          <div>
            <label className="block text-[10px] uppercase tracking-[0.2em] text-accent mb-1">DOI</label>
            <input
              value={doi}
              onChange={(e) => setDoi(e.target.value)}
              placeholder="10.xxxx/yyyy"
              className="w-full border border-border bg-background px-2 py-1.5"
            />
          </div>
          <div>
            <label className="block text-[10px] uppercase tracking-[0.2em] text-accent mb-1">
              ORCIDs (comma-separated, in author order)
            </label>
            <input
              value={orcids}
              onChange={(e) => setOrcids(e.target.value)}
              placeholder="0000-0000-0000-0000, 0000-0000-0000-0001"
              className="w-full border border-border bg-background px-2 py-1.5"
            />
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={featured}
              onChange={(e) => setFeatured(e.target.checked)}
            />
            <span>Feature this paper on the home page</span>
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={awardWinner}
              onChange={(e) => setAwardWinner(e.target.checked)}
            />
            <span>🏆 Mark as Award Winner</span>
          </label>
          {awardWinner && (
            <div>
              <label className="block text-[10px] uppercase tracking-[0.2em] text-accent mb-1">
                Award label (optional)
              </label>
              <input
                value={awardLabel}
                onChange={(e) => setAwardLabel(e.target.value)}
                placeholder="Best Paper — NYRJ Fall Symposium 2025"
                className="w-full border border-border bg-background px-2 py-1.5"
              />
            </div>
          )}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleSave}
              disabled={saving}
              className="px-4 py-1.5 bg-primary text-primary-foreground text-[10px] uppercase tracking-[0.2em] hover:bg-accent transition disabled:opacity-50"
            >
              {saving ? "Saving…" : "Save"}
            </button>
            {msg && <span className="text-xs text-muted-foreground">{msg}</span>}
          </div>
        </div>
      )}
    </div>
  );
}

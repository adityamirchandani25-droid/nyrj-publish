import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useId, useState, type FormEvent } from "react";
import { SiteLayout } from "@/components/SiteLayout";
import {
  bridgeSupabaseSession,
  getSession,
  isResearcher,
  loginStaff,
  logout,
  signInStudent,
  signUpStudent,
  type Role,
  type Session,
} from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { loginAmbassador } from "@/lib/auth";

/**
 * Turns a raw sign-in failure into something a student can act on.
 * Service outages are reported as outages rather than as bad credentials,
 * so nobody is told their password is wrong when it isn't.
 */
function isServiceOutage(msg: string): boolean {
  return /failed to fetch|network|load failed|fetch failed|timeout|timed out|503|502|504|unavailable|unexpected error occurred/i.test(
    msg,
  );
}

const OUTAGE_MESSAGE =
  "Our sign-in service is temporarily unreachable. Your account is safe — please try again in a few minutes.";


export const Route = createFileRoute("/login")({
  validateSearch: (search: Record<string, unknown>) => ({
    account:
      search.account === "student" || search.account === "staff" || search.account === "ambassador"
        ? search.account
        : undefined,
    mode: search.mode === "signup" ? "signup" : undefined,
  }) as { account?: "student" | "staff" | "ambassador"; mode?: "signup" },
  head: () => ({
    meta: [
      { title: "Log In — NYRJ" },
      { name: "description", content: "Log in to the National Youth Research Journal." },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: LoginPage,
});

type StatusVal =
  | "initial review"
  | "editorial review"
  | "waiting for edits"
  | "secondary review"
  | "publishing"
  | "published";
type DecisionVal = "pending" | "accepted" | "declined";
type Submission = {
  id: string;
  manuscript_name: string;
  status: StatusVal;
  decision: DecisionVal;
  updated_at: string;
};

function LoginPage() {
  const navigate = useNavigate();
  const search = Route.useSearch();
  const searchRole: Role | null =
    search.account === "student"
      ? "researcher"
      : search.account === "staff"
        ? "staff"
        : search.account === "ambassador"
          ? "ambassador"
          : null;
  const [role, setRole] = useState<Role | null>(searchRole);
  const [current, setCurrent] = useState<Session | null>(null);

  useEffect(() => {
    bridgeSupabaseSession();
    setCurrent(getSession());
    const id = setInterval(() => setCurrent(getSession()), 500);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    setRole(searchRole);
  }, [searchRole]);

  function chooseRole(nextRole: Role | null) {
    setRole(nextRole);
    if (typeof window !== "undefined") {
      const account = nextRole === "researcher" ? "student" : nextRole;
      const nextUrl = account ? `/login?account=${account}` : "/login";
      window.history.replaceState(null, "", nextUrl);
    }
  }

  if (current) {
    return (
      <SiteLayout>
        <section className="mx-auto max-w-3xl px-6 py-16">
          <p className="text-[10px] uppercase tracking-[0.35em] text-accent">Signed In</p>
          <h2 className="font-serif text-4xl text-primary mt-3">
            Welcome, {current.username}
          </h2>
          <p className="mt-3 text-muted-foreground">
            You are logged in as{" "}
            <span className="text-accent uppercase tracking-[0.2em] text-xs">{current.role}</span>.
          </p>
          <div className="mt-6 flex gap-4">
            <button
              onClick={() => navigate({ to: "/" })}
              className="px-5 py-2.5 bg-primary text-primary-foreground text-xs uppercase tracking-[0.2em] hover:bg-accent transition"
            >
              Go to Home
            </button>
            <button
              onClick={async () => {
                await logout();
                setCurrent(null);
              }}
              className="px-5 py-2.5 border border-primary text-primary text-xs uppercase tracking-[0.2em] hover:bg-primary hover:text-primary-foreground transition"
            >
              Log Out
            </button>
          </div>

          {isResearcher(current) && <SubmissionTracker email={current.username} />}
        </section>
      </SiteLayout>
    );
  }

  return (
    <SiteLayout>
      <section className="mx-auto max-w-2xl px-6 py-16">
        <p className="text-[10px] uppercase tracking-[0.35em] text-accent">Account Access</p>
        <h2 className="font-serif text-4xl sm:text-5xl text-primary mt-3">Log In</h2>
        <p className="mt-3 text-muted-foreground">Choose how you'd like to sign in.</p>

        {role === null && (
          <div className="mt-10 grid sm:grid-cols-3 gap-4">
            <a
              href="/login?account=student"
              onClick={(e) => { e.preventDefault(); chooseRole("researcher"); }}
              className="border border-border bg-card p-6 text-left hover:border-accent transition"
            >
              <p className="text-[10px] uppercase tracking-[0.25em] text-accent">Student</p>
              <h3 className="font-serif text-2xl text-primary mt-2">Student Login</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Sign in or create an account with your email and password.
              </p>
            </a>
            <a
              href="/login?account=staff"
              onClick={(e) => { e.preventDefault(); chooseRole("staff"); }}
              className="border border-border bg-card p-6 text-left hover:border-accent transition"
            >
              <p className="text-[10px] uppercase tracking-[0.25em] text-accent">Staff</p>
              <h3 className="font-serif text-2xl text-primary mt-2">Staff Login</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                For editors with publishing access.
              </p>
            </a>
            <a
              href="/review"
              className="border border-border bg-card p-6 text-left hover:border-accent transition"
            >
              <p className="text-[10px] uppercase tracking-[0.25em] text-accent">Peer Reviewer</p>
              <h3 className="font-serif text-2xl text-primary mt-2">Reviewer Login</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                For invited peer reviewers. Create an account — access is granted once our editors
                approve it.
              </p>
            </a>
            <a
              href="/login?account=ambassador"
              onClick={(e) => { e.preventDefault(); chooseRole("ambassador"); }}
              className="border border-border bg-card p-6 text-left hover:border-accent transition"
            >
              <p className="text-[10px] uppercase tracking-[0.25em] text-accent">Ambassador</p>
              <h3 className="font-serif text-2xl text-primary mt-2">Ambassador Login</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                For chapter leads registering clubs and reporting attendance.
              </p>
            </a>

          </div>
        )}

        {role === "staff" && (
          <StaffForm onBack={() => chooseRole(null)} onSuccess={() => navigate({ to: "/" })} />
        )}
        {role === "researcher" && (
          <StudentOtpForm
            onBack={() => chooseRole(null)}
            onSuccess={() => setCurrent(getSession())}
          />
        )}
        {role === "ambassador" && (
          <AmbassadorForm onBack={() => chooseRole(null)} onSuccess={() => navigate({ to: "/ambassador" })} />
        )}
      </section>
    </SiteLayout>
  );
}

function StaffForm({ onBack, onSuccess }: { onBack: () => void; onSuccess: () => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const r = await loginStaff(username, password);
      if (r.ok) {
        setError(null);
        onSuccess();
      } else setError(r.error);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="mt-10 border border-border bg-card p-6 space-y-4 max-w-md">
      <p className="text-[10px] uppercase tracking-[0.25em] text-accent">Staff Login</p>
      <FieldRow label="Username" value={username} onChange={setUsername} />
      <FieldRow label="Password" type="password" value={password} onChange={setPassword} />
      {error && <p className="text-xs text-destructive">{error}</p>}
      <div className="flex items-center gap-4">
        <button className="px-5 py-2.5 bg-primary text-primary-foreground text-xs uppercase tracking-[0.2em] hover:bg-accent transition">
          Log In
        </button>
        <button
          type="button"
          onClick={onBack}
          className="text-xs text-muted-foreground hover:text-accent underline underline-offset-4"
        >
          ← Choose a different login
        </button>
      </div>
    </form>
  );
}

function AmbassadorForm({ onBack, onSuccess }: { onBack: () => void; onSuccess: () => void }) {
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);


  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setError(null);
    try {
      const r = await loginAmbassador(name, password);
      if (r.ok) onSuccess();
      else setError(r.error);
    } finally { setBusy(false); }
  }

  return (
    <div className="mt-10 border border-border bg-card p-6 space-y-4 max-w-md">
      <p className="text-[10px] uppercase tracking-[0.25em] text-accent">Ambassador Login</p>
      <form onSubmit={submit} className="space-y-4">
        <FieldRow label="Your Name" value={name} onChange={setName} placeholder="Jane Doe" />
        <FieldRow label="Ambassador Password" type="password" value={password} onChange={setPassword} />
        {error && <p className="text-xs text-destructive">{error}</p>}
        <div className="flex items-center gap-4">
          <button
            disabled={busy}
            className="px-5 py-2.5 bg-primary text-primary-foreground text-xs uppercase tracking-[0.2em] hover:bg-accent transition disabled:opacity-50"
          >
            {busy ? "Signing in…" : "Log In"}
          </button>
          <button
            type="button"
            onClick={onBack}
            className="text-xs text-muted-foreground hover:text-accent underline underline-offset-4"
          >
            ← Back
          </button>
        </div>
      </form>

      <p className="pt-4 border-t border-border text-xs text-muted-foreground">
        Forgot the password? Email NYRJINFO@Gmail.com and the team will help you.
      </p>
    </div>
  );
}

function StudentOtpForm({ onBack, onSuccess }: { onBack: () => void; onSuccess: () => void }) {
  const navigate = useNavigate();
  const search = Route.useSearch();
  const searchMode = search.mode === "signup" ? "signup" : "login";
  const [mode, setMode] = useState<"login" | "signup">(searchMode);
  const [step, setStep] = useState<"auth" | "profile">("auth");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [age, setAge] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  async function sendReset() {
    const normalized = email.trim().toLowerCase();
    if (!normalized) {
      setError("Enter your email address above, then click “Forgot your password?”.");
      return;
    }
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const { error: rErr } = await supabase.auth.resetPasswordForEmail(normalized, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (rErr) throw rErr;
      setNotice(
        "If an account exists for that email, we've sent a password reset link. Check your inbox (and spam folder).",
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't send the reset email. Please try again.");
    } finally {
      setBusy(false);
    }
  }


  useEffect(() => {
    setMode(searchMode);
    setError(null);
  }, [searchMode]);

  function chooseMode(nextMode: "login" | "signup") {
    setMode(nextMode);
    setError(null);
    if (typeof window !== "undefined") {
      window.history.replaceState(
        null,
        "",
        nextMode === "signup" ? "/login?account=student&mode=signup" : "/login?account=student",
      );
    }
  }

  async function routeAfterAuth() {
    const { count } = await supabase
      .from("submissions")
      .select("id", { count: "exact", head: true });
    if ((count ?? 0) > 0) {
      onSuccess();
    } else {
      navigate({ to: "/" });
    }
  }

  async function submitLogin(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await signInStudent(email, password);
      await routeAfterAuth();
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Login failed.";
      if (isServiceOutage(msg)) {
        setError(OUTAGE_MESSAGE);
      } else if (/invalid.*credentials/i.test(msg)) {
        setError("That email or password doesn't match an account. If you're new, use Sign up below.");
      } else if (/not confirmed/i.test(msg)) {
        setError("Your account isn't confirmed yet. Try signing up again to reactivate it.");
      } else {
        setError(msg);
      }
    } finally {
      setBusy(false);
    }
  }

  async function submitSignup(e: FormEvent) {
    e.preventDefault();
    const normalizedEmail = email.trim().toLowerCase();
    if (!fullName.trim()) {
      setError("Please enter your full name.");
      return;
    }
    if (!normalizedEmail) {
      setError("Please enter your email address.");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const data = await signUpStudent(normalizedEmail, password, fullName);
      if (!data.session) {
        setError("If this email already has an account, please use Log in instead. If this is a new account, wait a moment and try logging in.");
        setMode("login");
        return;
      }
      setStep("profile");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Sign up failed.";
      if (isServiceOutage(msg)) {
        setError(OUTAGE_MESSAGE);
      } else if (/registered|already/i.test(msg)) {
        setError("An account with that email already exists. Please log in instead.");
      } else if (/invalid.*email/i.test(msg)) {
        setError("Please enter a valid email address.");
      } else if (/weak|password/i.test(msg)) {
        setError("Please use a stronger password with at least 6 characters.");
      } else {
        setError("We couldn't create the account. Please check the email and password, then try again.");
      }
    } finally {
      setBusy(false);
    }
  }

  async function saveProfile(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const { data: userData } = await supabase.auth.getUser();
      const uid = userData.user?.id;
      if (!uid) throw new Error("Not signed in.");
      const profileEmail = userData.user?.email ?? email.trim().toLowerCase();
      const { error: upErr } = await supabase.from("profiles").upsert({
        id: uid,
        email: profileEmail,
        full_name: fullName.trim(),
        phone: phone.trim(),
        age: age.trim() ? Number(age.trim()) : null,
      });
      if (upErr) throw upErr;
      await routeAfterAuth();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save profile.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mt-10 border border-border bg-card p-6 space-y-4 max-w-md">
      <p className="text-[10px] uppercase tracking-[0.25em] text-accent">
        {mode === "login" ? "Student Login" : "Student Sign Up"}
      </p>

      {step === "auth" && mode === "login" && (
        <form onSubmit={submitLogin} className="space-y-4">
          <FieldRow
            label="Email Address"
            type="email"
            value={email}
            onChange={setEmail}
            placeholder="you@example.com"
          />
          <FieldRow label="Password" type="password" value={password} onChange={setPassword} />
          {error && <p className="text-xs text-destructive">{error}</p>}
          {notice && <p className="text-xs text-accent">{notice}</p>}
          <button
            type="button"
            onClick={sendReset}
            disabled={busy}
            className="text-xs text-muted-foreground hover:text-accent underline underline-offset-4 disabled:opacity-50"
          >
            Forgot your password?
          </button>

          <div className="flex items-center gap-4">
            <button
              disabled={busy}
              className="px-5 py-2.5 bg-primary text-primary-foreground text-xs uppercase tracking-[0.2em] hover:bg-accent transition disabled:opacity-50"
            >
              {busy ? "Signing in…" : "Log In"}
            </button>
            <button
              type="button"
              onClick={onBack}
              className="text-xs text-muted-foreground hover:text-accent underline underline-offset-4"
            >
              ← Back
            </button>
          </div>
          <p className="pt-4 border-t border-border text-xs text-muted-foreground">
            Don't have an account?{" "}
            <a
              href="/login?account=student&mode=signup"
              onClick={() => {
                chooseMode("signup");
              }}
              className="text-accent underline underline-offset-4"
            >
              Sign up here
            </a>
          </p>
        </form>
      )}

      {step === "auth" && mode === "signup" && (
        <form onSubmit={submitSignup} className="space-y-4">
          <FieldRow
            label="Full Name"
            value={fullName}
            onChange={setFullName}
            placeholder="Jane Doe"
          />
          <FieldRow
            label="Email Address"
            type="email"
            value={email}
            onChange={setEmail}
            placeholder="you@example.com"
          />
          <FieldRow
            label="Password"
            type="password"
            value={password}
            onChange={setPassword}
            placeholder="At least 6 characters"
          />
          {error && <p className="text-xs text-destructive">{error}</p>}
          <div className="flex items-center gap-4">
            <button
              disabled={busy}
              className="px-5 py-2.5 bg-primary text-primary-foreground text-xs uppercase tracking-[0.2em] hover:bg-accent transition disabled:opacity-50"
            >
              {busy ? "Creating…" : "Create Account"}
            </button>
            <a
              href="/login?account=student"
              onClick={() => {
                chooseMode("login");
              }}
              className="text-xs text-muted-foreground hover:text-accent underline underline-offset-4"
            >
              ← Back to login
            </a>
          </div>
        </form>
      )}

      {step === "profile" && (
        <form onSubmit={saveProfile} className="space-y-4">
          <p className="text-sm">Just a few quick details to finish your account.</p>
          <FieldRow label="Full Name" value={fullName} onChange={setFullName} />
          <FieldRow label="Phone Number" type="tel" value={phone} onChange={setPhone} placeholder="(555) 555-5555" />
          <FieldRow label="Age" type="number" value={age} onChange={setAge} placeholder="e.g. 16" />
          <p className="text-xs text-muted-foreground italic">
            We don't sell your information. Please refer to our{" "}
            <a href="/privacy" className="text-accent underline underline-offset-2">
              Privacy Policy
            </a>{" "}
            for more information.
          </p>
          {error && <p className="text-xs text-destructive">{error}</p>}
          <button
            disabled={busy}
            className="px-5 py-2.5 bg-primary text-primary-foreground text-xs uppercase tracking-[0.2em] hover:bg-accent transition disabled:opacity-50"
          >
            {busy ? "Saving…" : "Save & Continue"}
          </button>
        </form>
      )}
    </div>
  );
}

function FieldRow({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  placeholder?: string;
}) {
  const id = useId();
  return (
    <div>
      <label htmlFor={id} className="block text-xs uppercase tracking-[0.2em] text-accent mb-1">{label}</label>
      <input
        id={id}
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required
        placeholder={placeholder}
        className="w-full border border-border bg-background px-3 py-2 text-sm"
      />
    </div>
  );
}

function SubmissionTracker({ email }: { email: string }) {
  const [rows, setRows] = useState<Submission[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    (async () => {
      const { data, error } = await supabase
        .from("submissions")
        .select("id, manuscript_name, status, decision, updated_at")
        .order("updated_at", { ascending: false });
      if (!active) return;
      if (error) setError(error.message);
      else setRows((data ?? []) as Submission[]);
    })();
    return () => {
      active = false;
    };
  }, [email]);

  return (
    <div className="mt-14 border-t-2 border-primary pt-8">
      <p className="text-[10px] uppercase tracking-[0.35em] text-accent">Your Submissions</p>
      <h3 className="font-serif text-3xl text-primary mt-2">Track Submissions</h3>
      <p className="mt-3 text-muted-foreground text-sm">
        Live status of every manuscript tied to{" "}
        <span className="text-accent">{email}</span>.
      </p>

      {error && <p className="mt-4 text-xs text-destructive">{error}</p>}

      {rows === null && !error && (
        <p className="mt-6 text-sm text-muted-foreground">Loading…</p>
      )}

      {rows && rows.length === 0 && (
        <p className="mt-6 text-sm text-muted-foreground italic">
          No submissions yet. Once you submit a manuscript and an editor records it, it will appear
          here.
        </p>
      )}

      {rows && rows.length > 0 && (
        <ul className="mt-6 space-y-3">
          {rows.map((r) => (
            <li key={r.id} className="border border-border bg-card p-4">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <p className="font-serif text-lg text-primary">{r.manuscript_name}</p>
                <DecisionBadge decision={r.decision} />
              </div>
              <p className="mt-2 text-xs uppercase tracking-[0.2em] text-muted-foreground">
                Status: <span className="text-accent">{r.status}</span>
              </p>
              {r.decision === "declined" && (
                <p className="mt-2 text-xs text-muted-foreground italic">
                  (If you would like to appeal, please email{" "}
                  <a
                    href="mailto:NYRJINFO@gmail.com"
                    className="text-primary underline underline-offset-2"
                  >
                    NYRJINFO@gmail.com
                  </a>
                  )
                </p>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function DecisionBadge({ decision }: { decision: DecisionVal }) {
  const styles =
    decision === "accepted"
      ? "bg-accent text-accent-foreground"
      : decision === "declined"
        ? "bg-destructive text-destructive-foreground"
        : "bg-muted text-muted-foreground";
  return (
    <span
      className={`px-2 py-0.5 text-[10px] uppercase tracking-[0.2em] ${styles}`}
    >
      {decision}
    </span>
  );
}
